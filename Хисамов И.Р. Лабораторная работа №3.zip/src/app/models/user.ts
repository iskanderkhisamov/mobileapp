export class User {
  img: string;
  family: string;
  birthday2: string;
  vk: string;
  birthday: string;
  phonenumber: string;
  user: string;
  skype: string;
  login: string;
}
